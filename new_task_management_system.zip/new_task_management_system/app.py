from flask import Flask
from routers.task_router import task_bp
from routers.user_router import user_bp

app = Flask(__name__)

# Register Blueprints
app.register_blueprint(task_bp, url_prefix='/tasks')
app.register_blueprint(user_bp, url_prefix='/users')

@app.route("/")
def home():
    return {"message": "Flask Task Management API is running!"}

if __name__ == "__main__":
    # Initialize the database
    from utils.db import db_creation
    db_creation()
    
    app.run(debug=True)
