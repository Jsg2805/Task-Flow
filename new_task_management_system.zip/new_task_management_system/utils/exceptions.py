class UserAlreadyExistsError(Exception):
    pass

class TaskAlreadyExistsError(Exception):
    pass

class EntityNotFoundError(Exception):
    pass
